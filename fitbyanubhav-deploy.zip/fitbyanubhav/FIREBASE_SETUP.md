# 🔥 Firebase Setup Instructions

Follow these steps ONCE to connect your live database.
Takes about 10 minutes.

---

## Step 1 — Create a Firebase Project

1. Go to **console.firebase.google.com**
2. Sign in with your Google account
3. Click **"Add project"**
4. Name it: `fitbyanubhav`
5. Disable Google Analytics (not needed) → Click **Create project**

---

## Step 2 — Create a Firestore Database

1. In your Firebase project, click **"Firestore Database"** (left sidebar)
2. Click **"Create database"**
3. Choose **"Start in test mode"** → click Next
4. Choose your region (e.g. `asia-south1` for India) → click **Enable**

---

## Step 3 — Get Your Config Keys

1. Click the **gear icon** (⚙️) → **Project settings**
2. Scroll down to **"Your apps"**
3. Click the **</>** (web) icon
4. Register app name: `fitbyanubhav-web` → click **Register app**
5. You'll see a block of code like this:

```js
const firebaseConfig = {
  apiKey: "AIzaSy...",
  authDomain: "fitbyanubhav.firebaseapp.com",
  projectId: "fitbyanubhav",
  storageBucket: "fitbyanubhav.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abc123"
};
```

6. **Copy these values**

---

## Step 4 — Add Config to the App

1. Open `src/App.jsx`
2. Find the section at the top that says:
```js
const firebaseConfig = {
  apiKey: "REPLACE_WITH_YOUR_API_KEY",
  ...
```
3. Replace all the `REPLACE_WITH_YOUR_...` values with your real values from Step 3
4. Save the file

---

## Step 5 — Deploy

1. Commit and push to GitHub
2. Vercel will auto-redeploy
3. Open the app — it will seed your client data automatically on first load ✅

---

## ✅ What happens after setup

- All client data lives in Firebase (cloud)
- When you update a training plan → clients see it **instantly**
- New clients you register are saved to Firebase immediately
- Data is safe even if you clear your phone

---

## 🔒 Security (important!)

Firestore is in "test mode" which allows open access for 30 days.
Before the 30 days are up, go to Firestore → Rules and replace with:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if true;
    }
  }
}
```

This keeps it open (fine for a small private app with trusted users).

